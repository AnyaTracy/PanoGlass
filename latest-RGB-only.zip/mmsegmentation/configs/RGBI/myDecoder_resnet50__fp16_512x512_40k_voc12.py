_base_ = [
    '../_base_/models/myDecoder_resnet50.py',
    '../_base_/datasets/pascal_voc12.py', '../_base_/default_runtime.py',
    '../_base_/schedules/schedule_80k.py'
]
crop_size = (512, 512)

model = dict(
    decode_head=dict(num_classes=2),
    auxiliary_head=dict(num_classes=2)
)

# By default, models are trained on 8 GPUs with 2 images per GPU
data = dict(samples_per_gpu=8, workers_per_gpu=8)
# fp16 settings
optimizer_config = dict(type='Fp16OptimizerHook', loss_scale='dynamic')
# fp16 placeholder
fp16 = dict(loss_scale=512.)

